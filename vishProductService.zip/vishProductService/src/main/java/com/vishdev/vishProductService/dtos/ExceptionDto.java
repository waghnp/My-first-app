package com.vishdev.vishProductService.dtos;

import org.springframework.http.HttpStatus;

public class ExceptionDto {
	private HttpStatus statusCode;
	private String erroMessage;
	
	public ExceptionDto(HttpStatus status, String message) {
		this.statusCode = status;
		this.erroMessage = message;
	}
	
	public HttpStatus getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}
	public String getErroMessage() {
		return erroMessage;
	}
	public void setErroMessage(String erroMessage) {
		this.erroMessage = erroMessage;
	}
}
