package com.vishdev.vishProductService.dtos;

public class ProductResponseDto {
//	  "id": 2,
//	    "title": "Microsoft Xbox X/S Wireless...",
//	    "image": "https://storage...",
//	    "price": 57,
//	    "description": "Experience the modernized design...",
//	    "brand": "microsoft",
//	    "model": "Xbox X/S",
//	    "color": "white",
//	    "category": "gaming",
//	    "popular": true,
//	    "discount": 4
	private Long id;
	private String title;
	private String image;

	private double price;
	private String description;
	private String brand;
	private String model;
	private String color;
	private String category;
	private boolean popular;
	private double discount;
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public boolean isPopular() {
		return popular;
	}
	public void setPopular(boolean popular) {
		this.popular = popular;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	
}
