package com.vishdev.vishProductService.dtos;

import java.util.List;

public class FakeStoreProductDto {

//	 {
//	  "status": "SUCCESS",
//	  "message": "Here you've a single product requested for id 2",
//	  "product": {
//	    "id": 2,
//	    "title": "Microsoft Xbox X/S Wireless...",
//	    "image": "https://storage...",
//	    "price": 57,
//	    "description": "Experience the modernized design...",
//	    "brand": "microsoft",
//	    "model": "Xbox X/S",
//	    "color": "white",
//	    "category": "gaming",
//	    "popular": true,
//	    "discount": 4
//	  }
//	}
	
	private String status;
	
	private String message;
	
	private ProductResponseDto product;
	
	private List<ProductResponseDto> products;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ProductResponseDto getProduct() {
		return product;
	}

	public void setProduct(ProductResponseDto product) {
		this.product = product;
	}

	public List<ProductResponseDto> getProducts() {
		return products;
	}

	public void setProducts(List<ProductResponseDto> products) {
		this.products = products;
	}
	
	
}
