package com.vishdev.vishProductService.models;

public class Category {

}
