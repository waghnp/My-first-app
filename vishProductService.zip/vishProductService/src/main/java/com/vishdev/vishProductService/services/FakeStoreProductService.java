package com.vishdev.vishProductService.services;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import com.vishdev.vishProductService.dtos.FakeStoreProductDto;
import com.vishdev.vishProductService.dtos.GenericProductDto;
import com.vishdev.vishProductService.dtos.ProductResponseDto;
import com.vishdev.vishProductService.exceptions.NotFoundException;

@Service
public class FakeStoreProductService implements ProductService{

	private RestTemplateBuilder restTemplateBuilder;
	
	private String getProductRequestURL = "https://fakestoreapi.in/api/products/{id}";
	private String deleteProductRequestURL = "https://fakestoreapi.in/api/products/{id}";
	private String getAllProductsRequestURL = "https://fakestoreapi.in/api/products";
	private String createProductRequestURL = "https://fakestoreapi.in/api/products";
	
	public FakeStoreProductService(RestTemplateBuilder restTemplateBuilder) {
		this.restTemplateBuilder = restTemplateBuilder;
	}
	
	private GenericProductDto convertProductResponseDTO_TO_GenericDTO(ProductResponseDto productResponseDto) {
		GenericProductDto product = new GenericProductDto();
		product.setTitle(productResponseDto.getTitle());
		product.setCategory(productResponseDto.getCategory());
		product.setDescription(productResponseDto.getDescription());
		product.setImage(productResponseDto.getImage());
		product.setPrice(productResponseDto.getPrice());
		
		product.setBrand(productResponseDto.getBrand());
		product.setModel(productResponseDto.getModel());
		product.setColor(productResponseDto.getColor());
		product.setDiscount(productResponseDto.getDiscount());
		return product;
	}

	public GenericProductDto getProductById(Long id) throws NotFoundException {
		RestTemplate restTemplate = restTemplateBuilder.build();
		ResponseEntity<FakeStoreProductDto> response =  restTemplate.getForEntity(getProductRequestURL, FakeStoreProductDto.class, id);

		FakeStoreProductDto fakeStoreProductDto = response.getBody();

		ProductResponseDto productResponseDto = fakeStoreProductDto.getProduct();
 	
		if(productResponseDto.getId() != id) {
			throw new NotFoundException("product with id : "+ id + " have not found");
		}

		return convertProductResponseDTO_TO_GenericDTO(productResponseDto);
	}
	
	public List<GenericProductDto> getProducts() {
		RestTemplate restTemplate = restTemplateBuilder.build();
		ResponseEntity<FakeStoreProductDto> response =  restTemplate.getForEntity(getAllProductsRequestURL, FakeStoreProductDto.class);
		FakeStoreProductDto fakeStoreProductDto = response.getBody();

		List<ProductResponseDto> productList= fakeStoreProductDto.getProducts();
		
		List<GenericProductDto> products = new ArrayList<GenericProductDto>();
		
		for(int i=0; i<productList.size();i++) {
			ProductResponseDto product = productList.get(i);
			products.add(convertProductResponseDTO_TO_GenericDTO(product));
		}
		
		return products;
	}


	
	public GenericProductDto createProduct(GenericProductDto product) {
	    RestTemplate restTemplate = restTemplateBuilder.build();

	    Map<String, String> payload = new HashMap<>();
	    payload.put("title", product.getTitle());
	    payload.put("brand", product.getBrand());
	    payload.put("model", product.getModel());
	    payload.put("color", product.getColor());
	    payload.put("category", product.getCategory());
	    payload.put("discount", String.valueOf(product.getDiscount()));
	    payload.put("price", String.valueOf(product.getPrice()));
	    
	    // ✅ Add required fields
	    payload.put("image", product.getImage() != null ? product.getImage() : "https://example.com/default.jpg");
	    payload.put("description", product.getDescription() != null ? product.getDescription() : "No description available");


        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, String>> request = new HttpEntity<>(payload, headers);
        
	    try {
	        ResponseEntity<FakeStoreProductDto> response = restTemplate.postForEntity(createProductRequestURL, request, FakeStoreProductDto.class);
	        FakeStoreProductDto fakeStoreProductDto = response.getBody();

	        ProductResponseDto createdProduct = fakeStoreProductDto.getProduct();

	        return convertProductResponseDTO_TO_GenericDTO(createdProduct);

	    } catch (HttpClientErrorException e) {
	        System.err.println("API Error: " + e.getResponseBodyAsString());
	        throw new RuntimeException("External API error: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
	    }
	}

	
	public FakeStoreProductDto deleteProduct(Long id) {
	    RestTemplate restTemplate = restTemplateBuilder.build();
		
		RequestCallback requestCallback = restTemplate.acceptHeaderRequestCallback(FakeStoreProductDto.class);
		ResponseExtractor<ResponseEntity<FakeStoreProductDto>> responseExtractor = restTemplate.responseEntityExtractor(FakeStoreProductDto.class);
		ResponseEntity<FakeStoreProductDto> response = restTemplate.execute(deleteProductRequestURL, HttpMethod.DELETE, requestCallback, responseExtractor, id);
		return response.getBody();
	}
	
	public FakeStoreProductDto updateProduct(Long id, GenericProductDto product) {
	    RestTemplate restTemplate = restTemplateBuilder.build();
		
		RequestCallback requestCallback = restTemplate.httpEntityCallback(product, FakeStoreProductDto.class);
		ResponseExtractor<ResponseEntity<FakeStoreProductDto>> responseExtractor = restTemplate.responseEntityExtractor(FakeStoreProductDto.class);
		ResponseEntity<FakeStoreProductDto> response = restTemplate.execute(deleteProductRequestURL, HttpMethod.PUT, requestCallback, responseExtractor, id);
		
		return response.getBody();
	}

}
