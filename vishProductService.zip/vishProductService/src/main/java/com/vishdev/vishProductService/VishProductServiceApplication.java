package com.vishdev.vishProductService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VishProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VishProductServiceApplication.class, args);
	}

}
