package com.vishdev.vishProductService.services;

import java.util.List;

import com.vishdev.vishProductService.dtos.FakeStoreProductDto;
import com.vishdev.vishProductService.dtos.GenericProductDto;
import com.vishdev.vishProductService.exceptions.NotFoundException;

public interface ProductService {
	GenericProductDto getProductById(Long id) throws NotFoundException;
	
	List<GenericProductDto> getProducts();
	
	GenericProductDto createProduct(GenericProductDto product);
	
	FakeStoreProductDto deleteProduct(Long id);
	
	FakeStoreProductDto updateProduct(Long id, GenericProductDto product);
}
