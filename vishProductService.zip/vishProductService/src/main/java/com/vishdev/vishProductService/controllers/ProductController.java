package com.vishdev.vishProductService.controllers;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vishdev.vishProductService.dtos.ExceptionDto;
import com.vishdev.vishProductService.dtos.FakeStoreProductDto;
import com.vishdev.vishProductService.dtos.GenericProductDto;
import com.vishdev.vishProductService.exceptions.NotFoundException;
import com.vishdev.vishProductService.services.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	private ProductService productService;
	
	public ProductController(ProductService productService){
		this.productService = productService;
	}
	
	@GetMapping("/{id}")
	public GenericProductDto getProductById(@PathVariable("id") Long id) throws NotFoundException {
		return productService.getProductById(id);
	}
	
//	@ExceptionHandler(NotFoundException.class)
//	private ResponseEntity<ExceptionDto> handleNotFoundException(NotFoundException notFoundException) {
//		return new ResponseEntity<ExceptionDto>(new ExceptionDto(HttpStatus.NOT_FOUND, notFoundException.getMessage()), HttpStatus.NOT_FOUND);
//	}
	
	
	@GetMapping
	public List<GenericProductDto> getProducts(){
		return productService.getProducts();
	}
	
	@PostMapping
	public GenericProductDto createProduct(@RequestBody GenericProductDto product) {
		System.out.println("product controller "+ product.getTitle());
		return productService.createProduct(product);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<FakeStoreProductDto> deleteProduct(@PathVariable Long id){
		FakeStoreProductDto deletedProduct = productService.deleteProduct(id);
		ResponseEntity<FakeStoreProductDto> response = new ResponseEntity<FakeStoreProductDto>(deletedProduct, HttpStatus.OK);
		return response;
	}
	
	@PutMapping("/{id}")
	public FakeStoreProductDto updateProduct(@PathVariable Long id, @RequestBody GenericProductDto product) {
		return productService.updateProduct(id, product);
	}
}
