package com.vishdev.vishProductService.exceptions;

public class NotFoundException extends Exception{
	public NotFoundException(String message) {
		super(message);
	}
}
