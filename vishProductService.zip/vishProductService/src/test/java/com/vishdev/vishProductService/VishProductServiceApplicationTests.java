package com.vishdev.vishProductService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VishProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
